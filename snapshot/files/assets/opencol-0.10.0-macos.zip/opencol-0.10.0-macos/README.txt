OpenCol 0.10.0 -- Sid Meier's Colonization (DOS, version 3.0), rebuilt.

OpenCol plays your own copy of the DOS game: it contains nothing of the game.

To play, start opencol. The first time, it asks for the folder of your copy
of the game, the one with VICEROY.EXE (in the GOG version, the COLONIZE folder),
or any folder above it, and remembers it. Started in the game's folder, it plays
that copy without asking.

macOS asks first: OpenCol is not signed by Apple. Right-click opencol and choose Open,
or run  xattr -dr com.apple.quarantine .  in the folder.

Your saved games are kept in the saves folder here, your maps in the maps
folder, and the settings (OPENCOL.INI) and the log beside opencol: each copy of
OpenCol keeps its own, and may play its own copy of the game. Keep this folder
where you can write to it. OpenCol 0.7 kept its games and maps beside the
program; the first start moves them into saves and maps.
The saved games in the game's folder can still be loaded; the game's folder is
not changed, unless OpenCol itself is in it.
OPENCOL.INI is a text file: each setting is explained in it, and may be changed
while OpenCol is closed.
To choose another copy, delete the "game = " line in OPENCOL.INI, or name it
for one run:
  opencol --game FOLDER [--save FOLDER]

Settings (in the main menu, and in the GAME menu while you play), Display:
  Screen Size  how much of the map you see (320 x 200, the original's, up to
               1280 x 800, or the whole window);
  UI Scale     how big it all is on your screen.
The main menu's Map Editor opens the map editor. --no-sound plays without sound.
F11 or Alt+Enter switches to full screen.

https://github.com/OpenCol/OpenCol
