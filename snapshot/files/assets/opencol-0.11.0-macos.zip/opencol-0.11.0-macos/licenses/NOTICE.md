# NOTICE

## What OpenCol is derived from

OpenCol rebuilds **Sid Meier's Colonization for DOS** (version 3.0, February 1995),
**© 1994 MicroProse Software, Inc.** The rights in that game are held by its present owner, not
by this project. The game's code here was recovered from a copy of the game the author owns, as
preservation and interoperability work, and OpenCol runs only with the player's own copy of the
game.

## What is whose

| Part | What it is | Terms |
|---|---|---|
| `src/port/`, `src/platform/`, `src/main/` | OpenCol's own code: the machine, the memory, the DOS and C library the game runs on, the window, the sound card | MIT ([LICENSE](LICENSE)) |
| `tools/`, `tests/`, `cmake/`, `docs/`, `.github/`, `CMakeLists.txt`, the top-level Markdown | OpenCol's own tools, tests and documents | MIT ([LICENSE](LICENSE)) |
| `src/game/`, `src/include/` | the game's code and data layout, reconstructed from the shipped program and edited since | **no license offered** (below) |
| `decomp/` | the decompilation OpenCol started from, a git submodule of [OpenCol/dos-decomp](https://github.com/OpenCol/dos-decomp) | its own [LICENSE](decomp/LICENSE) and [NOTICE](decomp/NOTICE.md) |
| `src/mapedit/` | the 1994 map editor, from [OpenCol/mapedit](https://github.com/OpenCol/mapedit) | its own [LICENSE](src/mapedit/LICENSE) and [NOTICE](src/mapedit/NOTICE.md) |
| `third_party/libx86emu/`, `third_party/ymfm/` | the CPU that runs the original's sound driver, the AdLib's OPL2 chip | their own licenses, in their folders |

**`src/game/` and `src/include/` are a reconstruction of someone else's program.** Every one
of the game's functions there began as C that compiles to the shipped machine code, and the
records and the data segment's layout are the original's. That is why the port plays exactly
like the original, and also why this project cannot grant a license over these files. No
license is offered for them, and nothing in [LICENSE](LICENSE) should be read as one. If you
want to reuse them, ask the rights holder.

## What is not distributed here

The game is not in this repository, and neither are its data, art, music, text or resources:
OpenCol reads them from the player's own copy (`VICEROY.EXE` and its files) when it starts. The
released programs contain OpenCol's code, the reconstructed game code, and the third-party
libraries above, with their licenses in the download's `licenses/` folder.

## Trademarks

*Sid Meier's Colonization*, *MicroProse* and *Sid Meier* are trademarks of their respective
owners. This project is not affiliated with, endorsed by, or connected to MicroProse Software,
Inc., Take-Two Interactive, Firaxis Games, or Sid Meier.

## Takedown

If you hold rights in *Sid Meier's Colonization* and object to any material here, open an
issue or contact the author and it will be removed.
