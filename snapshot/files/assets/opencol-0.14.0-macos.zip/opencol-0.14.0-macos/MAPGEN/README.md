# Map generators

Each folder here is a map generator: a Lua script, `generator.lua`, that makes a New World in place
of the original's code ([docs/proposals/map-generators.md](../docs/proposals/map-generators.md),
the sandbox and the table `classic` in [docs/scripting.md](../docs/scripting.md)).

| Folder | Generator |
|---|---|
| `classic/` | **Classic (Lua)**: the original's generator in Lua. For the same seed and CUSTOMIZE choices it makes exactly the original's map, proven for every choice (`tests/rules/test_mapgen_lua.py`). |

There is no menu to choose one yet. To try one, start OpenCol with the debug switch naming the
script: `OPENCOL_MAP_GENERATOR=MAPGEN/classic/generator.lua`. Without the switch, the game uses the
original's own C++ code, as always.

## Making a variant

1. Copy `classic/` to a folder of your own, e.g. `MAPGEN/wetter/`.
2. At the end of `generator.lua`, give it its own `id` (never reused), `name` and `version`.
3. **Before you change anything else, switch its random numbers to the script's own `rng`.**
   Replace `rand_range(lo, hi)` (the original's `rand()`) with `rng:int(lo, hi)` everywhere. The
   original's random numbers also decide the villages, the start squares and the rest of the
   game, so a generator that draws them differently changes more than its map. With `rng` your
   map comes from a seed of its own, and the Classic game is never affected.
4. Drop `classic.leave`, `classic.rivers_begin` and `classic.rivers_end`: they only exist so that
   Classic (Lua) leaves the memory exactly as the original does.
5. Now change what you like: the land's amount in `generate_new_world`, the climate bands, how
   wet the fertility sweeps make the land, how many rivers `do_rivers` lays.

Keep to integers: a map then comes out the same on every computer. The comments in
`classic/generator.lua` name each step of the original.
