-- Classic (Lua): the original's New World generator, rewritten in Lua.
--
-- This is build_map(0)'s block from src/game/map/generate.cpp (generate_new_world, elevate, blob,
-- blob2, island, bloop, do_rivers), one Lua function per C function, in the same order. For the
-- same rand() state and the same five CUSTOMIZE choices it makes the same New World as the C++,
-- byte for byte: the same planes, the same rand() draws in the same order, the same build_check()
-- calls, and the same values left in memory. tests/rules/test_mapgen_lua.py proves it for every
-- choice, at 58 x 72 and on a bigger map.
--
-- Run it with OPENCOL_MAP_GENERATOR=MAPGEN/classic/generator.lua. The C++ stays the default.
--
-- Making your own generator from this one
-- ----------------------------------------
-- Copy this folder (MAPGEN/my-generator/), give it a new id and name below, and change what you
-- like. As soon as you change anything, draw your numbers from `rng` (rng:int(lo, hi),
-- rng:chance(pct), the script's own generator) and not from `classic.rand_range`, the
-- original's rand(). Then the Classic game's random numbers, which decide the villages, the start
-- squares and everything after, are never touched by your map. Only a generator that has to be
-- the original again, draw for draw, uses classic.rand_range. The same goes for
-- classic.leave/rivers_begin/rivers_end: they only matter for a byte-for-byte copy of the original.
--
-- C's arithmetic
-- --------------
-- The original works in 16-bit C integers. Lua's integers are 64-bit, its // and % round down
-- (C's / and % round towards zero), and its >> shifts zeroes in. Where that could differ, this
-- file uses classic.i16 (wrap to 16 bits), classic.div and classic.mod (C's / and %). The land's
-- box (g_x_lo .. g_y_hi) is bytes in the original's memory, but OpenCol keeps g_x_hi and g_y_hi
-- whole (bigger maps: docs/map-size-plan.md), so they are not wrapped here either.
--
-- The planes (as the original uses them while it generates)
--   0: the terrain byte (low 5 bits the terrain, 0x20 hills, 0x80 with it mountains, 0x40 river)
--   1: scratch: the land's height while the land is made, later "forest here" marks
--   3: scratch: one land blob at a time, then do_rivers' copy of plane 0

local c = classic
local i16, div, mod = c.i16, c.div, c.mod
local get, set, rand_range, build_check = c.get, c.set, c.rand_range, c.build_check
local is_ocean, on_map = c.is_ocean, c.on_map

-- terrain ids (src/include/game/terrain.h)
local TUNDRA, DESERT, PLAINS, PRAIRIE, GRASSLAND, SAVANNAH, MARSH, SWAMP = 0, 1, 2, 3, 4, 5, 6, 7
local ARCTIC, OCEAN = 24, 25

-- the map and the original's globals while the block runs (left in memory at the end: leave)
local W, H                       -- g_map_size
local choice                     -- g_custom_choice[0..4], from 0 as in C
local land_count                 -- g_land_count
local x_lo, x_hi, y_lo, y_hi     -- g_x_lo .. g_y_hi

local DIR_DX, DIR_DY = c.dir_dx, c.dir_dy
local ORTHO_DX, ORTHO_DY = c.ortho_dx, c.ortho_dy
local RING_DX, RING_DY = c.ring_dx, c.ring_dy

-- C's ABS of an int16 (macros.h). It is a macro: its argument is evaluated twice, once for the
-- test and once for the value. When the argument draws a random number, it draws twice, so it is
-- given here as a function, called twice, exactly as the C does.
local function abs_twice(f)
  if f() > 0 then
    return f()
  end
  return i16(-f())
end

-- ABS of a plain int16 value (no draw)
local function abs16(v)
  if v > 0 then return v end
  return i16(-v)
end

-- the land blobs ---------------------------------------------------------------------------

-- bloop: a square of land (and its east and south neighbours) into the blob, plane 3
-- The squares of plane 3 set since elevate cleared it, each once. elevate's count reads these
-- instead of the whole plane (the C walks all w x h bytes): the same squares, as plane 3 holds
-- nothing else, and far fewer calls on a big map.
local blob_seen, blob_list

local function blob_put(x, y)
  set(3, x, y, 1)
  local k = y * W + x
  if not blob_seen[k] then
    blob_seen[k] = true
    blob_list[#blob_list + 1] = k
  end
end

local function bloop(x, y)
  if x ~= 0 and y ~= 0 and W > x and H > y then
    blob_put(x, y)
    if W - 1 > x then blob_put(x + 1, y) end
    if H - 1 > y then blob_put(x, y + 1) end
  end
  build_check()
end

-- a blob walks diagonally, laying land, until it has walked its length or leaves the land's box
local function inside(x, y)
  return x_lo < x and x_hi > x and y_lo < y and y_hi > y
end

local function blob(x, y)
  local n = rand_range(1, 64) + 2
  while n ~= 0 and inside(x, y) do          -- C: while (n-- != 0 && ...)
    n = n - 1
    bloop(x, y)
    local dir = rand_range(1, 4) * 2 - 1    -- a diagonal: 1, 3, 5 or 7
    x = i16(x + DIR_DX[dir])
    y = i16(y + DIR_DY[dir])
  end
  build_check()
end

-- blob2 (Land Form 2): a wider blob, with land on the diagonals now and then
local function blob2(x, y)
  local n = rand_range(1, 48) + 2
  while n ~= 0 and inside(x, y) do
    n = n - 1
    bloop(x, y)
    if rand_range(1, 4) == 1 then bloop(x + 1, y + 1) end
    if rand_range(1, 4) == 1 then bloop(x - 1, y + 1) end
    if rand_range(1, 4) == 1 then bloop(x + 1, y - 1) end
    if rand_range(1, 4) == 1 then bloop(x - 1, y - 1) end
    local dir = rand_range(1, 4) * 2 - 1
    x = i16(x + DIR_DX[dir])
    y = i16(y + DIR_DY[dir])
  end
  build_check()
end

-- island: a short walk on the straight directions, a square at a time
local function island(x, y)
  local n = rand_range(1, 16) + 2
  while n ~= 0 and inside(x, y) do
    n = n - 1
    blob_put(x, y)
    local dir = rand_range(1, 4) * 2 - 2    -- straight: 0, 2, 4 or 6
    x = i16(x + DIR_DX[dir])
    y = i16(y + DIR_DY[dir])
  end
  build_check()
end

-- elevate: one blob (pick_land 0) or one to three islands in the sea (pick_land 1) laid on plane
-- 3, then added to the land's height on plane 1, and counted
local function elevate(pick_land)
  c.fill(3, 0)
  blob_seen, blob_list = {}, {}
  local x, y
  repeat
    x = rand_range(1, W - 16) + 7
    y = rand_range(1, H - 8) + 3
  until not (pick_land ~= 0 and get(1, x, y) ~= 0)
  if pick_land ~= 0 then
    local r = rand_range(1, 10)
    island(x, y)
    if r >= 7 then island(x, y) end
    if r >= 8 then island(x, y) end
  else
    if choice[1] >= 2 then
      blob2(x, y)
    else
      blob(x, y)
    end
  end
  -- every square of the blob raises the land there by one (a byte: it wraps at 256), and counts
  for _, k in ipairs(blob_list) do
    local xx, yy = k % W, k // W
    set(1, xx, yy, (get(1, xx, yy) + 1) & 0xff)
    land_count = i16(land_count + 1)
  end
  build_check()
end

-- the rivers -------------------------------------------------------------------------------

-- do_rivers: rivers walk from a random head until they meet the sea or another river; a river
-- that meets something may become a major river downstream; forest grows around a river's head.
-- move and ni are do_rivers' stack variables the original leaves in memory (rivers_begin/end).
local function do_rivers()
  local rivers, tries = 0, 0
  local x, y, v, dir, move, ni, linked, len, turn
  local head_x, head_y, qx, qy = 0, 0, 0, 0
  local want_tries = c.per_area(512)
  local want_rivers = c.per_area(i16((((choice[0] << 2) + (choice[3] << 2)) + 8) << 1))
  c.rivers_begin()
  move, ni = 0, 0
  repeat
    c.copy(3, 0)                            -- plane 3: the map before this river, to undo it
    tries = tries + 1
    len = 0
    repeat                                  -- a head on flat land
      x = rand_range(1, W - 2)
      y = rand_range(1, H - 2)
      v = get(3, x, y)
    until not ((v & 0x20) ~= 0 or is_ocean(x, y) ~= 0)
    head_x, head_y = x, y
    dir = rand_range(0, 3) * 2
    turn = rand_range(0, 1)
    repeat                                  -- the river walks
      v = v | 0x40
      set(0, x, y, v)
      len = len + 1
      linked = 0
      ni = 0
      while linked == 0 and ni < 4 do       -- the sea or a river beside it: it joins there
        local nx = ORTHO_DX[ni] + x
        local ny = ORTHO_DY[ni] + y
        if is_ocean(nx, ny) ~= 0 or (get(3, nx, ny) & 0x40) ~= 0 then
          linked = 1
          v = get(0, nx, ny) | 0x40
          set(0, nx, ny, v)
          qx, qy = x, y
        end
        ni = ni + 1
      end
      local pct = rand_range(0, 99)
      if pct < 60 then
        move = dir                          -- straight on
      else
        if pct > 95 then turn = turn ~= 0 and 0 or 1 end
        if turn ~= 0 then
          move = mod(i16(dir + 2), 8)       -- a right turn
        else
          move = mod(i16(dir + 6), 8)       -- a left turn
        end
        turn = turn ~= 0 and 0 or 1
      end
      x = i16(DIR_DX[move] + x)
      y = i16(DIR_DY[move] + y)
      dir = move
      v = get(3, x, y)
    until not (linked == 0 and on_map(x, y) ~= 0 and (v & 0x40) == 0 and (v & 0x20) == 0)
    if (linked == 0 and (v & 0x40) == 0) or len < 3 then
      c.copy(0, 3)                          -- it went nowhere: undone
    else
      rivers = rivers + 1
      if linked ~= 0 and rand_range(1, choice[3] * 2 + 12) > 6 then
        -- a major river, from where it joined, back up the river
        local major = rand_range(1, choice[3] * 2 + 3)
        v = get(0, qx, qy)
        repeat
          v = v | 0x80
          set(0, qx, qy, v)
          move = -1
          ni = 0
          while move < 0 and ni < 4 do
            x = ORTHO_DX[ni] + qx
            y = ORTHO_DY[ni] + qy
            v = get(0, x, y)
            if (v & 0x40) ~= 0 and (v & 0x80) == 0 then
              move = ni
              qx, qy = x, y
              break                         -- C's break: ni is not counted up
            end
            ni = ni + 1
          end
          major = major - 1
        until not (major > 0 and move >= 0)
      end
      -- forest around the river's head
      ni = 0
      while ni < 20 do
        x = RING_DX[ni] + head_x
        y = RING_DY[ni] + head_y
        v = get(0, x, y)
        if (v & 0x1f) < 0x10 and rand_range(0, 1) ~= 0 then
          v = v + 8
          set(0, x, y, v)
        end
        ni = ni + 1
      end
    end
    build_check()
  until not (tries < want_tries and want_rivers > rivers)
  c.rivers_end(move, ni)
end

-- the New World ----------------------------------------------------------------------------

-- generate_new_world: build_map(0)'s block. x is build_map's own x (a variable the original
-- keeps on its stack): its last value is left in memory, so the loops below use it as the C does.
local function generate_new_world()
  local x, y, t, mask, equator, fert, type, ice, fflag, hy, step, need, cnt
  local ha, hb = 0, 0
  x = 0

  -- the land's box, all sea
  land_count = 0
  c.fill(0, OCEAN)
  c.fill(1, 0)
  x_lo = 3
  x_hi = W - 6
  y_lo = 0
  y_hi = H
  ice = rand_range(0, 1)                    -- the polar sea on the north or on the south
  if ice ~= 0 then
    y_lo = 5
  else
    y_hi = H - 6
  end

  -- land blobs until there is land enough (Land Mass and Land Form)
  local want_land = c.per_area(i16((((choice[0] + choice[1]) + 1) << 3) * 0x28))
  repeat
    elevate(0)
  until not (want_land > land_count)

  -- islands, until there are up to 15 land masses
  c.find_continents()
  cnt = 0
  for i = 0, 15 do
    if c.region_size(i) ~= 0 then cnt = cnt + 1 end
  end
  need = 16 - (cnt + 1)
  if need > 0 then
    if choice[1] > 0 then need = need - rand_range(0, need) end
    for _ = 0, need - 1 do elevate(1) end
  end

  -- filling diagonal gaps: two squares of land touching only at a corner get the other two.
  -- The C steps x and y back by one inside the loops, so they are while loops here.
  y = 1
  while H - 1 > y do
    x = 1
    while W - 1 > x do
      mask = 0
      if get(1, x, y) ~= 0 then mask = mask | 1 end
      if get(1, x + 1, y) ~= 0 then mask = mask | 2 end
      if get(1, x, y + 1) ~= 0 then mask = mask | 4 end
      if get(1, x + 1, y + 1) ~= 0 then mask = mask | 8 end
      if mask == 6 or mask == 9 then
        set(1, x + 1, y, 1)
        set(1, x, y + 1, 1)
        set(1, x + 1, y + 1, 1)
        if x ~= 0 then x = x - 1 end
        if y ~= 0 then y = y - 1 end
      end
      x = x + 1
    end
    y = y + 1
  end
  build_check()

  -- climate bands, by the distance from the equator (Temperature), and hills and mountains
  -- where the land is two and three high
  for yy = 0, H - 1 do
    y = yy
    x = 0
    while W > x do
      t = get(1, x, y)
      mask = 0x19
      -- C: ABS((int16_t)(((h >> 1) + 8) - (rand_range(1, 16) + y))): two draws (abs_twice)
      equator = abs_twice(function()
        return i16(((H >> 1) + 8) - (rand_range(1, 16) + y))
      end)
      equator = i16(equator + (1 - choice[2]) * 2)
      if equator < 0 then equator = 0 end
      equator = i16(div(equator * 72, H))   -- bands of 4 rows in 72
      equator = equator >> 2                -- not negative here: Lua's >> is C's
      if equator == 0 then
        mask = 5                            -- savannah
      elseif equator == 1 then
        mask = 4                            -- grassland
      elseif equator == 2 then
        mask = 1                            -- desert
      elseif equator == 3 then
        mask = 3                            -- prairie
      elseif equator == 4 or equator == 5 then
        mask = 2                            -- plains
      else
        mask = 0                            -- tundra
      end
      if t == 0 then mask = 0x19 end        -- sea
      if t >= 2 then mask = mask | 0x20 end -- hills
      if t >= 3 then mask = mask | 0x80 end -- mountains
      set(0, x, y, mask)
      x = x + 1
    end
    build_check()
  end

  -- the fertility sweeps (Climate): a row's wetness comes in from the sea and dries out over the
  -- land, west to east then east to west, making the land wetter or drier as it goes
  for yy = 0, H - 1 do
    y = yy
    equator = abs16(i16((H >> 1) - y))
    local wet = i16(abs16(i16((H >> 2) - equator)) + (choice[3] << 2))
    fert = rand_range(0, wet)

    -- west to east
    x = 0
    while W > x do
      t = get(0, x, y)
      type = t & 0x1f
      if t == 25 then
        if wet > fert then fert = i16(fert + 1) end
      else
        if (t & 0x80) ~= 0 then
          fert = i16(fert - 3)
        elseif (t & 0x20) ~= 0 then
          t = t & 0xff5f
        elseif fert < 0 then                -- drier
          if type == GRASSLAND then
            type = PRAIRIE
          elseif type == PRAIRIE then
            if rand_range(0, abs16(fert)) ~= 0 then
              type = DESERT
            else
              type = PLAINS
              fert = i16(fert - 1)
            end
          elseif type == PLAINS then
            type = TUNDRA
          elseif type == TUNDRA then
            set(1, x, y, 2)
          end
        elseif fert > 0 then                -- wetter
          if type == SAVANNAH then
            fert = i16(fert - 2)
            if rand_range(0, 3) == 0 then type = SWAMP end
          elseif type == GRASSLAND then
            fert = i16(fert - 2)
            if rand_range(0, 3) == 0 then type = MARSH end
          elseif type == PRAIRIE then
            type = GRASSLAND
          elseif type == PLAINS then
            type = PRAIRIE
          elseif type == TUNDRA then
            type = PLAINS
          end
        end
        if fert > 0 then
          fert = i16(fert - rand_range(1, 7 - choice[3] * 2))
        elseif fert < 0 then
          fert = i16(fert + 1)
        end
      end
      t = (t & 0xe0) | type
      set(0, x, y, t)
      x = x + 1
    end

    -- east to west
    fert = 0
    x = W - 1
    while x >= 0 do
      t = get(0, x, y)
      type = t & 0x1f
      if type == OCEAN then
        if i16((equator >> 1) + choice[3]) > fert then fert = i16(fert + 1) end
      else
        if (t & 0x80) ~= 0 then
          fert = i16(fert - 3)
        elseif (t & 0x20) ~= 0 then
          t = t & 0xff5f
        elseif fert < 0 then
          -- (nothing: the original leaves the land as it is)
        elseif fert > 0 then
          if type == SAVANNAH then
            fert = i16(fert - 2)
            type = SWAMP
          elseif type == GRASSLAND then
            fert = i16(fert - 2)
            if rand_range(0, 1) == 0 then type = MARSH end
          elseif type == PRAIRIE then
            type = GRASSLAND
          elseif type == PLAINS then
            type = PRAIRIE
          elseif type == DESERT then
            type = PRAIRIE
          elseif type == TUNDRA then
            type = PLAINS
          end
        end
        if fert > 0 then
          fert = i16(fert - rand_range(1, 7 - choice[3] * 2))
        elseif fert < 0 then
          fert = i16(fert + 1)
        end
      end
      t = (t & 0xe0) | type
      set(0, x, y, t)
      x = x - 1
    end
    build_check()
  end

  -- hills and mountains: random squares, every other one a step from the last (the hidden fifth
  -- choice sets how many). ha and hb, the chances of hills and of mountains on them, are only
  -- reset on flat land: on hills and mountains they keep the last square's, as in the C.
  local hills = c.per_area(i16(choice[4] * 800 + 800))
  local i = 0
  while hills > i do
    if (i & 1) ~= 0 then
      step = rand_range(0, 8)
      x = i16(x + DIR_DX[step])
      y = i16(y + DIR_DY[step])
    else
      x = rand_range(1, W - 2)
      y = rand_range(1, H - 2)
    end
    t = get(0, x, y)
    type = t & 0x1f
    if (t & 0x80) ~= 0 then                 -- a mountain: maybe a lake
      if c.ocean(x, y) ~= 0 then t = t & 0xff5f end
    elseif (t & 0x20) ~= 0 then             -- a hill: a mountain
      t = t | 0x80
      set(1, x, y, 1)
    else
      ha, hb = 0, 0
      if type == TUNDRA then
        ha, hb = 1, 0
        if rand_range(0, 1) == 0 then type = PLAINS end
      elseif type == DESERT then
        ha, hb = 1, 1
        if rand_range(0, 1) == 0 then type = PRAIRIE end
      elseif type == PLAINS or type == PRAIRIE then
        if type == PRAIRIE and rand_range(0, 2) == 0 then type = PLAINS end
        ha, hb = 2, 2
        if rand_range(0, 1) == 0 then set(1, x, y, 2) end
      elseif type == GRASSLAND then
        ha, hb = 3, 1
        if rand_range(0, 1) == 0 then type = MARSH end
        if rand_range(0, 1) == 0 then set(1, x, y, 1) end
      elseif type == SAVANNAH then
        ha, hb = 3, 2
        if rand_range(0, 1) == 0 then type = SWAMP end
        if rand_range(0, 1) == 0 then set(1, x, y, 1) end
      elseif type == MARSH then
        ha, hb = 5, 3
        if rand_range(0, 1) == 0 then type = GRASSLAND end
        if rand_range(0, 1) == 0 then set(1, x, y, 2) end
      elseif type == SWAMP then
        ha, hb = 5, 3
        if rand_range(0, 1) ~= 0 then type = SAVANNAH end
        if rand_range(0, 1) ~= 0 then set(1, x, y, 2) end
      end
    end
    if ha ~= 0 and rand_range(0, ha) == 0 then
      t = t | 0x20
      if hb ~= 0 and rand_range(0, hb) == 0 then t = t | 0x80 end
    end
    t = (t & 0xe0) | type
    set(0, x, y, t)
    i = i + 1
  end
  build_check()

  -- forests: where plane 1 marks them, and on land by the water
  for yy = 0, H - 1 do
    y = yy
    build_check()
    x = 0
    while W > x do
      t = get(0, x, y)
      if t ~= 25 then
        if get(1, x, y) == 1 then
          if rand_range(0, 8) == 0 then
            t = t + 8
          else
            t = t + 16
          end
          set(0, x, y, t)
        else
          if c.water_access(x, y) ~= 0 then
            if rand_range(0, 1) == 0 then
              t = t + 8
            elseif rand_range(0, 4) ~= 0 then
              t = t + 16
            end
          end
          set(0, x, y, t)
        end
      end
      x = x + 1
    end
  end

  -- rivers
  do_rivers()

  -- the polar sea, the sea round the edge, and the arctic's sea lanes
  if ice ~= 0 then
    c.fill_rect(0, 0, 0, W, 4, 25)
  else
    c.fill_rect(0, 0, H - 4, W, 4, 25)
  end
  c.frame_rect(0, 2, 0, W - 3, H - 1, 25)
  i = 0
  while i < c.per_width(40) do
    set(0, rand_range(1, W) - 1, 1, 24)
    set(0, rand_range(1, W) - 1, H - 2, 24)
    i = i + 1
  end

  -- the high seas on the east: from the east edge to the first land, at most half the map
  for yy = 1, H - 2 do
    y = yy
    fflag = 1
    x = W - 1
    while fflag ~= 0 and (W >> 1) <= x do
      if is_ocean(x, y) ~= 0 then
        t = get(0, x, y)
        set(0, x, y, (t & 0xe0) + 0x1a)
      else
        fflag = 0
      end
      x = x - 1
    end
    build_check()
  end

  -- the sea lanes: ocean again off the east coast of each row's easternmost land, three rows up
  -- and down, so ships can reach the coast without crossing high seas all the way
  for yy = 1, H - 2 do
    y = yy
    fflag = -1
    x = W - 1
    while fflag < 0 and x >= 1 do
      if is_ocean(x, y) == 0 then fflag = x end
      x = x - 1
    end
    if fflag >= 0 then
      x = math.min(i16(fflag + 3), i16(W - 2))
      hy = y - 3
      while y + 3 >= hy do
        if on_map(x, hy) ~= 0 then
          while is_ocean(x, hy) == 0 and W - 2 > x do
            x = x + 1
          end
          if is_ocean(x, hy) ~= 0 then
            t = get(0, x, hy)
            set(0, x, hy, (t & 0xe0) | 0x19)
          end
        end
        hy = hy + 1
      end
    end
    build_check()
  end

  -- the high seas end at the first ocean west of them: everything further west is ocean
  for yy = 1, H - 2 do
    y = yy
    fflag = 1
    x = W - 1
    while x >= 1 do
      if fflag ~= 0 then
        if (get(0, x, y) & 0x1f) ~= 0x1a then fflag = 0 end
      elseif is_ocean(x, y) ~= 0 then
        t = get(0, x, y)
        set(0, x, y, (t & 0xe0) | 0x19)
      end
      x = x - 1
    end
    build_check()
  end

  -- the arctic rows: arctic on the land of rows 1 and h-2, some arctic on rows 2 and h-3, and
  -- some land flattened to tundra on rows 3 and h-4
  for k = 0, 1 do
    x = 0
    while W > x do
      y = (k ~= 0) and 1 or (H - 2)
      if is_ocean(x, y) == 0 then set(0, x, y, ARCTIC) end
      y = (k ~= 0) and 2 or (H - 3)
      if is_ocean(x, y) == 0 then
        t = c.terrain_at(x, y)
        t = ((rand_range(0, 1) ~= 0) and 24 or 0) | (t & 0xe0)
        set(0, x, y, t)
      end
      y = (k ~= 0) and 3 or (H - 4)
      if rand_range(0, 1) ~= 0 and is_ocean(x, y) == 0 then
        t = c.terrain_at(x, y)
        t = t & 0xe0
        set(0, x, y, t)
      end
      x = x + 1
    end
  end
  build_check()

  -- what the block leaves in memory, as the original leaves it
  c.leave{land_count = land_count, x_lo = x_lo, x_hi = x_hi, y_lo = y_lo, y_hi = y_hi, x = i16(x)}
end

-- the generator ----------------------------------------------------------------------------

local function generate(w, h, c0, c1, c2, c3, c4)
  W, H = w, h
  choice = {[0] = c0, c1, c2, c3, c4}
  generate_new_world()
end

return {
  api = 1,                       -- the `classic` table's API (docs/scripting.md)
  id = "classic",
  name = "Classic (Lua)",
  version = "1.0.0",
  author = "OpenCol, after the original's code",
  generate = generate,
}
